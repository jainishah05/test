$(function() 
{
  $("#add_product").validate(
  {
    rules: 
    {
      pname:{
        required: true,
      },
      price: {
        required: true,
        number: true
      },
      fileupload: {
        required: true,
        extension: "png|gif|jpeg|jpg"
      },
      category: {
        required: true,
      }
    },
    // Specify validation error messages
    messages: 
    {
      pname: "Please enter Product",
      price: {
        required: "Please enter Price",
        number: "Only Numbers are allowed",
        // range: "Please enter valid Price"
      }, 
      fileupload: {
        required: "Please Select Product Image",
        extension: "File should be .jpg, .jpeg, .png, .gif"
      },
      category: "Please select a Category"
    },
    submitHandler: function(form) {
      form.submit();
    },
  });
});